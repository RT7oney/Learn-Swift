//
//  SegmentCell.swift
//  smartmixer
//
//  Created by 姚俊光 on 14/9/21.
//  Copyright (c) 2014年 smarthito. All rights reserved.
//

import UIKit

class SegmentCell: UICollectionViewCell {
    
    //名字
    @IBOutlet var name:UILabel!
    //英文名字
    @IBOutlet var nameEng:UILabel!
    //附加显示信息
    var extendInfo:String!
    
}
